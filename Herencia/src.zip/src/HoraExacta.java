public class HoraExacta extends Hora
{
    int segundos;

    public HoraExacta(int hora, int minuto,int segundos)
    {
        super(hora, minuto);
    }

    public void setSegundos(int segundos)
    {
        this.segundos = segundos;
        if(segundos > 59 || segundos < 0)
        {
            System.out.println("los segundos deben estar entre 0 y 59");
            System.err.println(2);
        }
    }

    @Override
    public String toString()
    {
        return "HoraExacta{" +
                "hora=" + hora +
                ", minuto=" + minuto +
                ", segundos=" + segundos +
                '}';
    }

    public void inc()
    {
        segundos += 1;
        if(segundos > 59)
        {
            segundos = 0;
            minuto += 1;
            if(minuto > 59)
            {
                minuto = 0;
                hora += 1;
            }
        }

    }

    public void compare()
    {

    }
}
