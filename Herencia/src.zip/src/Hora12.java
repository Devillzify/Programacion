public class Hora12 extends Hora
{
    String momento;

    @Override
    public String toString()
    {
        return hora + ":" + minuto + ":" + momento;
    }

    public Hora12(int hora, int minuto)
    {
        super(hora, minuto);

       if(hora >= 13)
       {
           this.hora = hora - 12;
           if(hora >= 13)
           {
               momento = "PM";
           }
       }

       if(hora < 13)
       {
           momento = "AM";
       }

    }



}
